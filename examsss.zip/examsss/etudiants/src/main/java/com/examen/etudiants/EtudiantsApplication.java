package com.examen.etudiants;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EtudiantsApplication {

	public static void main(String[] args) {
		SpringApplication.run(EtudiantsApplication.class, args);
	}

}
